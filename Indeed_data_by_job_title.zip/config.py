Authentic_api_key = 'bc0a02c1dddea2b12aba42e7fbee9e69'
